
'''
sudo pip3 install firebase_admin
'''
import json

import firebase_admin
from firebase_admin import credentials
from firebase_admin import db



# Fetch the service account key JSON file contents
cred = credentials.Certificate('firebase_key.json')
# Initialize the app with a service account, granting admin privileges
firebase_admin.initialize_app(cred, {
    'databaseURL': "https://iot-vertical-farming-40e8a-default-rtdb.firebaseio.com"
})

'''firebase_admin.delete_app(firebase_admin.get_app()) ''' ##to delete all project app

########
ref1= db.reference()#all ref OR ==> ref = db.reference("/")

#if child found will update value if not found will add it as (key and value)
ref1.child("order").update({"sales":{"POS":{}}})
########

ref2 = db.reference('order/sales') #NOTE:if not found will create it

#reset it to new json and delete old
ref2.set({'POS':{"1":"ramallah","2":"hebron"}})

#push new json (the key will generate automaticlly)
ref2.child("invoice").push({'product':"book","amount":33,"price":3})

#push new json (the key will generate automaticlly)
ref2.child("invoice").push({'product':"bag","amount":2,"price":23})

#push new json (the key will generate automaticlly) same ref2.push({json});
ref2.child("invoice").push().set({'product':"computer","amount":17,"price":4})

#if child found will update value if not found will add it as (key and value)
ref2.child("POS").update({"1":"Ramallah"})
ref2.child("POS").update({"2":{"city":"Hebron"}})
ref2.child("POS").update({"3":"Jarusalem"})
ref2.child("POS").update({"4":"Nablus"})

#delete
ref2.child("POS").child("4").set({})


#return all
print("\n-------------------1----------------------\n")
print(ref2.get())

#order by auto key
print("\n-------------------2----------------------\n")
print(ref2.child("invoice").order_by_key().get())

#order by auto key first 2
print("\n-------------------3----------------------\n")
print(ref2.child("invoice").order_by_key().limit_to_first(2).get())

#order by auto key last 2
print("\n-------------------4----------------------\n")
print(ref2.child("invoice").order_by_key().limit_to_last(2).get())


##########################################
#To apply next method "order_by_child"
#we have to first set the key by which we are ordering as the index field via .indexOn rule in Firebase Security rules.
#this in rules tab in firebase website
'''
{
  "rules": {
    ".read": true,//"now < 1668376800000",  // 2022-11-14
    ".write": true,//"now < 1668376800000",  // 2022-11-14
      "order":
      {
        "sales":
        {
          "invoice":
          {
            ".indexOn": ["price"]
          }
        }

      }
  },
  
}

'''
##########################################

#return by order from first
print("\n-------------------5----------------------\n")
print(ref2.child("invoice").order_by_child("price").limit_to_first(2).get())

#return by order from last
print("\n-------------------6----------------------\n")
print(ref2.child("invoice").order_by_child("price").limit_to_last(2).get())

#return exactly at fixed value
print("\n-------------------7----------------------\n")
print(ref2.child("invoice").order_by_child("price").equal_to(23).get())






'''
#===============================LEARN MORE=================================
'''

'''
#######set value from json file#########

ref = db.reference("/")
ref.set({
	"Books":
	{
		"Best_Sellers": -1
	}
})

ref = db.reference("/Books/Best_Sellers")
import json
with open("book_info.json", "r") as f:
	file_contents = json.load(f)

for key, value in file_contents.items():
	ref.push().set(value)

########################################
'''


'''
####### Delete fixed Data #########
ref = db.reference("/Books/Best_Sellers")

for key, value in best_sellers.items():
	if(value["Author"] == "J.R.R. Tolkien"):
		ref.child(key).set({})
        


########################################
'''


'''
####### Update Data #########
ref = db.reference("/Books/Best_Sellers/")
best_sellers = ref.get()
print(best_sellers)
for key, value in best_sellers.items():
	if(value["Author"] == "J.R.R. Tolkien"):
		value["Price"] = 90
		ref.child(key).update({"Price":80})
        
        

########################################
'''





