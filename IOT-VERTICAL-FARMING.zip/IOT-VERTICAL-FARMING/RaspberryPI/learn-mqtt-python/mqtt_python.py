
'''
pip3 install paho-mqtt
'''


import time
import paho.mqtt.client as paho
from paho import mqtt

import threading



# setting callbacks for different events to see if it works, print the message etc.
def on_connect(client, userdata, flags, rc, properties=None):
    print("CONNACK received with code %s." % rc)
    
    if rc == 0:
      print("Connected to MQTT Broker!")
    else:
      print("Failed to connect, return code %d\n", rc)
      
      
# with this callback you can see if your publish was successful
def on_publish(client, userdata, mid, properties=None):
    print("publish OK => mid: " + str(mid))

# print which topic was subscribed to
def on_subscribe(client, userdata, mid, granted_qos, properties=None):
    print("Subscribed Ok => mid: " + str(mid) + " " + str(granted_qos))

# print message, useful for checking if it was successful
def on_message(client, userdata, msg):
    #print(msg.topic + " " + str(msg.qos) + " " + str(msg.payload))
    subscribe_function(str(msg.topic),str(msg.payload))

# using MQTT version 5 here, for 3.1.1: MQTTv311, 3.1: MQTTv31
client = paho.Client(client_id="client_name_id", userdata=None, protocol=paho.MQTTv31)
client.on_connect = on_connect

'''
# enable TLS for secure connection
client.tls_set(tls_version=mqtt.client.ssl.PROTOCOL_TLS)######
# set username and password
client.username_pw_set("yeczrtkd:yeczrtkd", "8GrG6YxV_fd1O40MvreyzIBGd_hfGta3")
'''

client.connect("mqtt-dashboard.com", 1883)
client.on_subscribe = on_subscribe
client.on_message = on_message
client.on_publish = on_publish

client.subscribe("vertical_farming/ESP_plant_id1/control/pump", qos=1)
client.subscribe("vertical_farming/ESP_plant_id1/manual_control/pump", qos=1)

client.subscribe("vertical_farming/ESP_plant_id1/sensor_value/ph", qos=1)


def subscribe_function(topic,msg):
  print("topic:"+topic+"  msg:"+msg)

def publish_mqtt(topic,msg):
  client.publish(topic, payload=msg, qos=1)


def auto_publish_test():

  while 1:

    publish_mqtt("vertical_farming/ESP_plant_id1/control/pump","on")
    
    time.sleep(2)




  
t1 = threading.Thread(target=lambda :client.loop_forever(), args=())
t1.start()

auto_publish_test()










